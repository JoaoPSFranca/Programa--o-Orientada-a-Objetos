package br.eud.ifsp.pep.exception;

public class TipoPagamentoInvalido extends Exception {
    public TipoPagamentoInvalido(String message) {
        super(message);
    }
}
