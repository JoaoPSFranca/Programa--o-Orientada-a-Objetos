package br.eud.ifsp.pep.exception;

public class CodigoInvalido extends Exception {
    public CodigoInvalido(String message) {
        super(message);
    }
}
