package br.edu.ifsp.pep;

public class Principal {
    public static void main(String[] args) {
        
    }
}
